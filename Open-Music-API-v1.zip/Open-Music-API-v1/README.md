# OPEN-MUSIC-API-V1
Ini adalah projek pertama membuat OPEN Music API pada kelas Belajar Fundamental Aplikasi BAck-End
